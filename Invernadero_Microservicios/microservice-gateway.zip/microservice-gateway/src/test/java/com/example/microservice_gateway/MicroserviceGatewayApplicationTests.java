package com.example.microservice_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
